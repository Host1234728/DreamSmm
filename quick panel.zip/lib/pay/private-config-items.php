<?php 

return [
    "techAppConfig" => [
        'payments' =>[
            'gateway_configuration' => [
                'paytm' => [
                    'paytmMerchantTestingSecretKey',
                    'paytmMerchantLiveSecretKey'
                ],
                'instamojo' => [
                    
                ]
            ]
        ]
    ]
];