<div class="col-md-8">
            <div class="settings-header__table">
                <div class="pull-left">
                    <form action="" method="post" enctype="multipart/form-data">

<input type="file" name="logo" id="preferenceLogo">
<button type="submit" class="btn btn-primary">Update Settings</button>
      </form></div>

                <div class="pull-right">
                    <form id="searchForm" action="/admin/appearance/files" method="GET">                        <div class="form-inline form-control__filter">
                            <label for="live-search" class="form-control__filter-icon"></label>
                            <input type="text" id="live-search" class="form-control form-control__filter-input" name="query" value="" placeholder="Search...">                        </div>
                    </form>                </div>
            </div>

                        <div id="filesContainer">
                <table class="table files__table">
    <thead>
    <tr>
        <th class="p-l" colspan="2">File</th>
        <th>URL</th>
        <th>Size</th>
        <th></th>
    </tr>
    </thead>
    <tbody>
        </tr>
    </tbody>
</table>

<nav>
    </nav>            </div>
        </div>
    </div>
</div>
