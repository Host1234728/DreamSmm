<?php
require '../vendor/autoload.php';
require '../app/init.php';
$smmapi = new SMMApi();
       



    
    
$mass = "old.smmpanel.click";
$order =    $mass[1];
				
$dab = "$mass[0]$mass[1]$mass[2]$mass[3]$mass[4]" ;

   echo $dab;
