<?php

$url = $_SERVER["SERVER_NAME"];
$last = substr($url, -1); 
$dab = "$url[0]$url[1]$url[2]$url[3]$url[4]$last" ; 

define('PATH', realpath('.'));
define('SUBFOLDER', false);
define('URL', "https://$url");
define('STYLESHEETS_URL', "//$url");
error_reporting(1);
date_default_timezone_set('Asia/Kolkata');

return [
  'db' => [
    'name'    =>  "thesmmxy_nordxpro",
    'host'    =>  'localhost',
    'user'    =>  "thesmmxy_nordxpro",
    'pass'    =>  "thesmmxy_nordxpro",
    'charset' =>  'utf8mb4' 
  ]
];

